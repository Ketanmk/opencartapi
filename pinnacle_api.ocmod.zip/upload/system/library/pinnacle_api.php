<?php

// IntelliSoftware IntelliSMS PHP Library
// Release: v1.0


class PinnacleApi
{
	public function sendPinnacleSMS ($sender, $apiurl, $apikey,$customer_phone,$body) 
	{
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $apiurl,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => "sender=".$sender."&numbers=".$customer_phone."&message=".$body."&messagetype=TXT",
		  CURLOPT_HTTPHEADER => array(
		    "apikey:".$apikey
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
		  return $err;
		} else {
		  return $response;
		}
	}
}


?>
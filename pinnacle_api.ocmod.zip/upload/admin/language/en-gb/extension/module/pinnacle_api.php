<?php
// Heading
$_['heading_title']    = 'Pinnacle SMS';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Pinnacle SMS module!';
$_['text_edit']        = 'Edit Pinnacle SMS Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_pinnacle_api_url']     = 'Pinnacle API URL';
$_['entry_pinnacle_api_account_sender']     = 'Pinnacle account Sender ID';
$_['entry_pinnacle_api_account_apikey']     = 'Pinnacle account API Key';
//$_['entry_twilio_sms_body']     = 'Message body';

// Help
$_['help_pinnacle_api_url']         = 'Find your Pinnacle API URL.';
$_['help_pinnacle_api_account_sender']         = 'Find your Pinnacle Account Sender ID';
$_['help_pinnacle_api_account_apikey']  = 'Find your Pinnacle Account  APIKEY';
//$_['help_pinnacle_sms_body']     =  'This is the body of the sms to be sent once an order is placed.';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Pinnacle SMS module!';